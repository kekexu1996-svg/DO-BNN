from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
import yaml

from .data import Standardizer, load_feature_table, make_train_val_split, split_by_year
from .esm import ESMConfig, train_with_esm
from .model import DOBNN
from .train import TrainConfig, evaluate_model, predict_mc, train_model


def load_config(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a dual-output BNN for wheat LAI and LNA prediction.")
    parser.add_argument("--config", required=True, help="Path to a YAML configuration file.")
    args = parser.parse_args()

    cfg = load_config(args.config)
    output_dir = Path(cfg.get("output_dir", "outputs"))
    output_dir.mkdir(parents=True, exist_ok=True)

    seed = int(cfg.get("seed", 42))
    np.random.seed(seed)
    torch.manual_seed(seed)

    data_cfg = cfg["data"]
    feature_cols = data_cfg["feature_cols"]
    target_cols = data_cfg.get("target_cols", ["LAI", "LNA"])
    x_raw, y_raw, frame = load_feature_table(data_cfg["csv_path"], feature_cols, target_cols)

    if "train_years" in data_cfg and "test_years" in data_cfg:
        train_all_idx, test_idx = split_by_year(
            frame,
            train_years=data_cfg["train_years"],
            test_years=data_cfg["test_years"],
            year_col=data_cfg.get("year_col", "year"),
        )
    else:
        all_idx = np.arange(len(frame))
        train_all_idx, test_idx = make_train_val_split(all_idx, validation_fraction=data_cfg.get("test_fraction", 0.25), random_state=seed)

    train_idx, val_idx = make_train_val_split(
        train_all_idx,
        validation_fraction=float(data_cfg.get("validation_fraction", 0.2)),
        random_state=seed,
    )

    x_scaler = Standardizer().fit(x_raw[train_idx])
    y_scaler = Standardizer().fit(y_raw[train_idx])
    x = x_scaler.transform(x_raw)
    y = y_scaler.transform(y_raw)

    train_cfg = TrainConfig(**cfg.get("training", {}))
    model_cfg = cfg.get("model", {})
    model = DOBNN(input_dim=x.shape[1], **model_cfg)

    if cfg.get("esm", {}).get("enabled", True):
        esm_cfg = ESMConfig(**{k: v for k, v in cfg.get("esm", {}).items() if k != "enabled"})
        model, sample_weight, history = train_with_esm(model, x[train_idx], y[train_idx], x[val_idx], y[val_idx], train_cfg, esm_cfg)
        np.save(output_dir / "sample_weight.npy", sample_weight)
    else:
        model, history = train_model(model, x[train_idx], y[train_idx], x[val_idx], y[val_idx], config=train_cfg)

    test_report = evaluate_model(model, x[test_idx], y[test_idx], y_scaler=y_scaler, device=train_cfg.device)
    pred_mean, pred_std = predict_mc(model, x[test_idx], mc_samples=int(cfg.get("inference", {}).get("mc_samples", 100)), device=train_cfg.device)
    pred_mean = y_scaler.inverse_transform(pred_mean)
    pred_std = pred_std * y_scaler.scale_

    torch.save(model.state_dict(), output_dir / "dobnn_state_dict.pt")
    np.savez(output_dir / "scalers.npz", x_mean=x_scaler.mean_, x_scale=x_scaler.scale_, y_mean=y_scaler.mean_, y_scale=y_scaler.scale_)
    np.savez(output_dir / "test_predictions.npz", index=test_idx, pred_mean=pred_mean, pred_std=pred_std, y_true=y_raw[test_idx])

    with open(output_dir / "metrics.json", "w", encoding="utf-8") as handle:
        json.dump(test_report, handle, indent=2)
    with open(output_dir / "history.json", "w", encoding="utf-8") as handle:
        json.dump(history, handle, indent=2)

    print(json.dumps(test_report, indent=2))
