from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    rng = np.random.default_rng(42)
    out_dir = Path("data")
    out_dir.mkdir(exist_ok=True)
    n_by_year = {2022: 81, 2023: 81, 2024: 54}
    rows = []

    for year, n in n_by_year.items():
        for _ in range(n):
            ndre = rng.uniform(0.25, 0.85)
            rvi = rng.uniform(2.0, 9.0)
            cvi = rng.uniform(0.1, 1.4)
            h_mean = rng.uniform(0.25, 1.05)
            h_cv = rng.uniform(0.05, 0.35)
            hp95 = h_mean + rng.uniform(0.05, 0.35)
            textures = rng.normal(0.0, 1.0, 12)
            lai = 0.8 + 3.2 * ndre + 0.9 * cvi + 0.6 * h_mean + 0.15 * textures[-1] + rng.normal(0, 0.18)
            lna = 0.5 + 1.1 * ndre + 0.8 * lai + 0.5 * cvi + 0.12 * textures[-1] + rng.normal(0, 0.28)
            row = {
                "year": year,
                "NDRE": ndre,
                "RVI": rvi,
                "CVI": cvi,
                "H_mean": h_mean,
                "H_CV": h_cv,
                "HP95th": hp95,
                "LAI": lai,
                "LNA": lna,
            }
            for name, value in zip(
                [
                    "SH_ENT",
                    "SH_ASM",
                    "SH_CON",
                    "SH_COR",
                    "SS_ENT",
                    "SS_ASM",
                    "SS_CON",
                    "SS_COR",
                    "SV_ENT",
                    "SV_ASM",
                    "SV_CON",
                    "SV_COR",
                ],
                textures,
            ):
                row[name] = value
            rows.append(row)

    path = out_dir / "wheat_features.csv"
    pd.DataFrame(rows).to_csv(path, index=False)
    print(f"Wrote {path} with {len(rows)} synthetic rows.")
    print("Run: python scripts/train.py --config configs/default.yaml")


if __name__ == "__main__":
    main()
