from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from .data import make_loader
from .metrics import regression_report
from .model import DOBNN


@dataclass
class TrainConfig:
    learning_rate: float = 1e-3
    batch_size: int = 16
    epochs: int = 800
    patience: int = 80
    mc_train_samples: int = 20
    lambda_lai: float = 1.0
    lambda_lna: float = 1.0
    lambda_kl: float = 1e-4
    device: str = "cpu"


def weighted_rmse_loss(pred: torch.Tensor, target: torch.Tensor, sample_weight: torch.Tensor, task_weights: torch.Tensor) -> torch.Tensor:
    error2 = (pred - target).pow(2) * task_weights
    per_sample = torch.sqrt(error2.mean(dim=1) + 1e-8)
    return (per_sample * sample_weight).mean()


def elbo_regression_loss(
    model: DOBNN,
    x: torch.Tensor,
    y: torch.Tensor,
    sample_weight: torch.Tensor,
    config: TrainConfig,
) -> torch.Tensor:
    task_weights = torch.tensor([config.lambda_lai, config.lambda_lna], device=x.device, dtype=x.dtype)
    losses = []
    for _ in range(config.mc_train_samples):
        pred = model(x, sample=True)
        losses.append(weighted_rmse_loss(pred, y, sample_weight, task_weights))
    regression = torch.stack(losses).mean()
    return regression + config.lambda_kl * model.kl_divergence() / max(len(x), 1)


@torch.no_grad()
def predict_mc(model: nn.Module, x: np.ndarray | torch.Tensor, mc_samples: int = 100, device: str = "cpu") -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    if not torch.is_tensor(x):
        x = torch.as_tensor(x, dtype=torch.float32)
    x = x.to(device)
    preds = []
    for _ in range(mc_samples):
        preds.append(model(x, sample=True).detach().cpu().numpy())
    stacked = np.stack(preds, axis=0)
    return stacked.mean(axis=0), stacked.std(axis=0)


def evaluate_model(
    model: nn.Module,
    x: np.ndarray,
    y: np.ndarray,
    y_scaler: Any | None = None,
    mc_samples: int = 100,
    device: str = "cpu",
) -> dict[str, dict[str, float]]:
    pred_mean, _ = predict_mc(model, x, mc_samples=mc_samples, device=device)
    y_eval = y
    if y_scaler is not None:
        pred_mean = y_scaler.inverse_transform(pred_mean)
        y_eval = y_scaler.inverse_transform(y)
    return regression_report(y_eval, pred_mean)


def train_model(
    model: DOBNN,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    sample_weight: np.ndarray | None = None,
    config: TrainConfig | None = None,
    checkpoint_path: str | Path | None = None,
) -> tuple[DOBNN, dict[str, list[float]]]:
    config = config or TrainConfig()
    device = torch.device(config.device)
    model.to(device)

    loader = make_loader(x_train, y_train, sample_weight, batch_size=config.batch_size, shuffle=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)

    history: dict[str, list[float]] = {"train_loss": [], "val_loss": []}
    best_state = None
    best_val = float("inf")
    stale_epochs = 0

    x_val_t = torch.as_tensor(x_val, dtype=torch.float32, device=device)
    y_val_t = torch.as_tensor(y_val, dtype=torch.float32, device=device)
    val_weight = torch.ones(len(x_val), dtype=torch.float32, device=device)

    for _epoch in range(config.epochs):
        model.train()
        batch_losses = []
        for xb, yb, wb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            wb = wb.to(device)
            optimizer.zero_grad()
            loss = elbo_regression_loss(model, xb, yb, wb, config)
            loss.backward()
            optimizer.step()
            batch_losses.append(float(loss.detach().cpu()))

        model.eval()
        with torch.no_grad():
            val_loss = elbo_regression_loss(model, x_val_t, y_val_t, val_weight, config)
        train_loss = float(np.mean(batch_losses))
        val_loss_value = float(val_loss.detach().cpu())
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss_value)

        if val_loss_value < best_val:
            best_val = val_loss_value
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            stale_epochs = 0
            if checkpoint_path is not None:
                torch.save(best_state, checkpoint_path)
        else:
            stale_epochs += 1

        if stale_epochs >= config.patience:
            break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history
