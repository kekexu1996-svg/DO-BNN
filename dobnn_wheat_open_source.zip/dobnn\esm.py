from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .model import DOBNN
from .train import TrainConfig, predict_mc, train_model


@dataclass
class ESMConfig:
    iterations: int = 5
    max_samples_per_iteration: int = 3
    selected_sample_weight: float = 2.0
    mc_samples: int = 100
    no_improve_patience: int = 1


def select_extreme_samples(
    model: DOBNN,
    x_pool: np.ndarray,
    already_selected: set[int] | None = None,
    max_samples: int = 3,
    mc_samples: int = 100,
    device: str = "cpu",
) -> list[int]:
    """Select uncertain and response-extreme samples from the training pool.

    The manuscript describes three criteria: high predictive uncertainty,
    potential local maximum response, and potential local minimum response.
    This implementation operationalizes them with MC predictive variance and
    standardized predictive means.
    """

    already_selected = already_selected or set()
    pred_mean, pred_std = predict_mc(model, x_pool, mc_samples=mc_samples, device=device)
    uncertainty_score = pred_std.mean(axis=1)

    mean_z = (pred_mean - pred_mean.mean(axis=0)) / np.maximum(pred_mean.std(axis=0), 1e-8)
    max_score = mean_z.max(axis=1)
    min_score = (-mean_z).max(axis=1)

    candidate_order = [
        int(np.argmax(uncertainty_score)),
        int(np.argmax(max_score)),
        int(np.argmax(min_score)),
    ]

    selected: list[int] = []
    for idx in candidate_order:
        if idx not in already_selected and idx not in selected:
            selected.append(idx)
        if len(selected) >= max_samples:
            break
    return selected


def train_with_esm(
    model: DOBNN,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    train_config: TrainConfig | None = None,
    esm_config: ESMConfig | None = None,
) -> tuple[DOBNN, np.ndarray, dict[str, list[float]]]:
    train_config = train_config or TrainConfig()
    esm_config = esm_config or ESMConfig()
    sample_weight = np.ones(len(x_train), dtype=np.float32)
    selected: set[int] = set()
    merged_history: dict[str, list[float]] = {"train_loss": [], "val_loss": []}
    best_val = float("inf")
    stale_rounds = 0

    for _iteration in range(esm_config.iterations + 1):
        model, history = train_model(
            model,
            x_train,
            y_train,
            x_val,
            y_val,
            sample_weight=sample_weight,
            config=train_config,
        )
        merged_history["train_loss"].extend(history["train_loss"])
        merged_history["val_loss"].extend(history["val_loss"])

        current_val = min(history["val_loss"]) if history["val_loss"] else float("inf")
        if current_val < best_val:
            best_val = current_val
            stale_rounds = 0
        else:
            stale_rounds += 1
        if _iteration >= esm_config.iterations or stale_rounds > esm_config.no_improve_patience:
            break

        new_indices = select_extreme_samples(
            model,
            x_train,
            already_selected=selected,
            max_samples=esm_config.max_samples_per_iteration,
            mc_samples=esm_config.mc_samples,
            device=train_config.device,
        )
        if not new_indices:
            break
        selected.update(new_indices)
        sample_weight[new_indices] = esm_config.selected_sample_weight

    return model, sample_weight, merged_history
