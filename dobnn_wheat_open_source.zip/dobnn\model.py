from __future__ import annotations

import math
from typing import Iterable, Sequence

import torch
from torch import nn
from torch.nn import functional as F


class BayesianLinear(nn.Module):
    """Mean-field Bayesian linear layer with a zero-mean Gaussian prior."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        prior_sigma: float = 1.0,
        rho_init: float = -5.0,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.prior_sigma = float(prior_sigma)

        weight_scale = 1.0 / math.sqrt(in_features)
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features).uniform_(-weight_scale, weight_scale))
        self.weight_rho = nn.Parameter(torch.full((out_features, in_features), rho_init))
        self.bias_mu = nn.Parameter(torch.zeros(out_features))
        self.bias_rho = nn.Parameter(torch.full((out_features,), rho_init))

    @staticmethod
    def _sigma(rho: torch.Tensor) -> torch.Tensor:
        return F.softplus(rho)

    def forward(self, x: torch.Tensor, sample: bool = True) -> torch.Tensor:
        if sample:
            weight = self.weight_mu + self._sigma(self.weight_rho) * torch.randn_like(self.weight_mu)
            bias = self.bias_mu + self._sigma(self.bias_rho) * torch.randn_like(self.bias_mu)
        else:
            weight = self.weight_mu
            bias = self.bias_mu
        return F.linear(x, weight, bias)

    def kl_divergence(self) -> torch.Tensor:
        return self._kl_normal(self.weight_mu, self._sigma(self.weight_rho)) + self._kl_normal(
            self.bias_mu, self._sigma(self.bias_rho)
        )

    def _kl_normal(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.Tensor:
        prior_var = self.prior_sigma**2
        var = sigma.pow(2)
        return 0.5 * torch.sum((var + mu.pow(2)) / prior_var - 1.0 + 2.0 * math.log(self.prior_sigma) - torch.log(var))


class DOBNN(nn.Module):
    """Dual-output Bayesian neural network for simultaneous LAI and LNA prediction."""

    def __init__(
        self,
        input_dim: int,
        hidden_dims: Sequence[int] = (32, 16),
        output_dim: int = 2,
        prior_sigma: float = 1.0,
    ) -> None:
        super().__init__()
        dims = [input_dim, *hidden_dims]
        self.layers = nn.ModuleList(
            BayesianLinear(dims[i], dims[i + 1], prior_sigma=prior_sigma) for i in range(len(dims) - 1)
        )
        self.output = BayesianLinear(dims[-1], output_dim, prior_sigma=prior_sigma)

    def forward(self, x: torch.Tensor, sample: bool = True) -> torch.Tensor:
        for layer in self.layers:
            x = F.relu(layer(x, sample=sample))
        return self.output(x, sample=sample)

    def kl_divergence(self) -> torch.Tensor:
        kl_terms: Iterable[torch.Tensor] = [layer.kl_divergence() for layer in self.layers]
        return sum(kl_terms, self.output.kl_divergence())
