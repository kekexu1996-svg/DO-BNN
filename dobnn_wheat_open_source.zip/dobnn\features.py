from __future__ import annotations

import numpy as np


def compute_ndre(reflectance_730: np.ndarray, reflectance_815: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Normalized difference red-edge index from 730 nm and 815 nm bands."""

    r730 = np.asarray(reflectance_730, dtype=np.float32)
    r815 = np.asarray(reflectance_815, dtype=np.float32)
    return (r815 - r730) / (r815 + r730 + eps)


def compute_rvi(reflectance_730: np.ndarray, reflectance_815: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Ratio vegetation index from 815 nm and 730 nm reflectance."""

    r730 = np.asarray(reflectance_730, dtype=np.float32)
    r815 = np.asarray(reflectance_815, dtype=np.float32)
    return r815 / (r730 + eps)


def depth_to_point_cloud(depth: np.ndarray, fx: float, fy: float, cx: float, cy: float) -> np.ndarray:
    """Reconstruct a point cloud from a depth image and pinhole intrinsics."""

    depth = np.asarray(depth, dtype=np.float32)
    rows, cols = np.indices(depth.shape)
    valid = np.isfinite(depth) & (depth > 0)
    z = depth[valid]
    x = (cols[valid] - cx) * z / fx
    y = (rows[valid] - cy) * z / fy
    return np.column_stack([x, y, z]).astype(np.float32)


def fit_ground_plane_svd(points: np.ndarray) -> tuple[np.ndarray, float]:
    """Fit a ground reference plane with least squares/SVD.

    Returns a unit normal vector and offset d for the plane n.x + d = 0.
    """

    points = np.asarray(points, dtype=np.float32)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points must have shape (n_samples, 3)")
    centroid = points.mean(axis=0)
    _, _, vh = np.linalg.svd(points - centroid, full_matrices=False)
    normal = vh[-1]
    normal = normal / np.maximum(np.linalg.norm(normal), 1e-8)
    if normal[2] < 0:
        normal = -normal
    d = -float(np.dot(normal, centroid))
    return normal.astype(np.float32), d


def orthogonal_distance_to_plane(points: np.ndarray, normal: np.ndarray, offset: float) -> np.ndarray:
    """Calculate orthogonal point-to-plane distances."""

    points = np.asarray(points, dtype=np.float32)
    normal = np.asarray(normal, dtype=np.float32)
    return np.abs(points @ normal + offset) / np.maximum(np.linalg.norm(normal), 1e-8)


def canopy_height_map_from_depth(
    depth: np.ndarray,
    fx: float,
    fy: float,
    cx: float,
    cy: float,
    ground_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Apply the CHCM idea to convert depth values into canopy heights.

    If `ground_mask` is provided, only those pixels are used to fit the ground
    plane. Otherwise, the lowest 20 percent of depth-derived points are used as
    a simple fallback.
    """

    depth = np.asarray(depth, dtype=np.float32)
    rows, cols = np.indices(depth.shape)
    valid = np.isfinite(depth) & (depth > 0)
    z = depth[valid]
    x = (cols[valid] - cx) * z / fx
    y = (rows[valid] - cy) * z / fy
    points = np.column_stack([x, y, z]).astype(np.float32)

    if ground_mask is not None:
        ground_points = depth_to_point_cloud(np.where(ground_mask, depth, 0.0), fx, fy, cx, cy)
    else:
        cutoff = np.quantile(points[:, 2], 0.2)
        ground_points = points[points[:, 2] <= cutoff]
    normal, offset = fit_ground_plane_svd(ground_points)
    distances = orthogonal_distance_to_plane(points, normal, offset)

    height_map = np.full(depth.shape, np.nan, dtype=np.float32)
    height_map[valid] = distances.astype(np.float32)
    return height_map


def extract_structural_features(height_map: np.ndarray, pixel_area: float = 1.0) -> dict[str, float]:
    """Extract H_mean, H_CV, HP95th, and CVI from a CHCM-corrected height map."""

    values = np.asarray(height_map, dtype=np.float32)
    values = values[np.isfinite(values) & (values > 0)]
    if values.size == 0:
        return {"H_mean": np.nan, "H_CV": np.nan, "HP95th": np.nan, "CVI": np.nan}
    h_mean = float(values.mean())
    return {
        "H_mean": h_mean,
        "H_CV": float(values.std() / max(abs(h_mean), 1e-8)),
        "HP95th": float(np.percentile(values, 95)),
        "CVI": float(values.sum() * pixel_area),
    }


def extract_hsv_glcm_features(rgb: np.ndarray, levels: int = 32, distances: tuple[int, ...] = (1,), angles: tuple[float, ...] = (0.0,)) -> dict[str, float]:
    """Extract HSV-channel GLCM texture features.

    Returns entropy, angular second moment, contrast, and correlation for the H,
    S, and V channels using names compatible with the default config.
    """

    try:
        from skimage.color import rgb2hsv
        from skimage.feature import graycomatrix, graycoprops
    except ImportError as exc:
        raise ImportError("extract_hsv_glcm_features requires scikit-image.") from exc

    rgb = np.asarray(rgb, dtype=np.float32)
    if rgb.max() > 1.0:
        rgb = rgb / 255.0
    hsv = rgb2hsv(rgb[..., :3])
    names = ["H", "S", "V"]
    out: dict[str, float] = {}
    for channel_index, name in enumerate(names):
        channel = np.clip(hsv[..., channel_index], 0, 1)
        quantized = np.floor(channel * (levels - 1)).astype(np.uint8)
        glcm = graycomatrix(quantized, distances=distances, angles=angles, levels=levels, symmetric=True, normed=True)
        probability = glcm / np.maximum(glcm.sum(), 1e-12)
        entropy = -np.sum(probability * np.log(probability + 1e-12))
        out[f"S{name}_ENT"] = float(entropy)
        out[f"S{name}_ASM"] = float(graycoprops(glcm, "ASM").mean())
        out[f"S{name}_CON"] = float(graycoprops(glcm, "contrast").mean())
        out[f"S{name}_COR"] = float(graycoprops(glcm, "correlation").mean())
    return out
