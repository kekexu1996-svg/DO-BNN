"""Dual-output Bayesian neural network for wheat LAI and LNA prediction."""

from .model import DOBNN, BayesianLinear
from .train import train_model, evaluate_model, predict_mc
from .metrics import regression_report
from .features import (
    canopy_height_map_from_depth,
    compute_ndre,
    compute_rvi,
    extract_hsv_glcm_features,
    extract_structural_features,
)

__all__ = [
    "BayesianLinear",
    "DOBNN",
    "compute_ndre",
    "compute_rvi",
    "canopy_height_map_from_depth",
    "extract_structural_features",
    "extract_hsv_glcm_features",
    "train_model",
    "evaluate_model",
    "predict_mc",
    "regression_report",
]
