from __future__ import annotations

import numpy as np


def r2_score_np(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    ss_res = np.sum((y_true - y_pred) ** 2, axis=0)
    ss_tot = np.sum((y_true - np.mean(y_true, axis=0)) ** 2, axis=0)
    return 1.0 - ss_res / np.maximum(ss_tot, 1e-12)


def rmse_np(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    return np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2, axis=0))


def rrmse_np(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    rmse = rmse_np(y_true, y_pred)
    denominator = np.mean(np.asarray(y_true), axis=0)
    return rmse / np.maximum(np.abs(denominator), 1e-12)


def regression_report(y_true: np.ndarray, y_pred: np.ndarray, target_names: tuple[str, ...] = ("LAI", "LNA")) -> dict[str, dict[str, float]]:
    r2 = r2_score_np(y_true, y_pred)
    rmse = rmse_np(y_true, y_pred)
    rrmse = rrmse_np(y_true, y_pred)
    return {
        name: {"r2": float(r2[i]), "rmse": float(rmse[i]), "rrmse": float(rrmse[i])}
        for i, name in enumerate(target_names)
    }
