from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset


@dataclass
class Standardizer:
    mean_: np.ndarray | None = None
    scale_: np.ndarray | None = None
    eps: float = 1e-8

    def fit(self, values: np.ndarray) -> "Standardizer":
        self.mean_ = np.asarray(values, dtype=np.float32).mean(axis=0)
        self.scale_ = np.asarray(values, dtype=np.float32).std(axis=0)
        self.scale_ = np.where(self.scale_ < self.eps, 1.0, self.scale_)
        return self

    def transform(self, values: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None:
            raise RuntimeError("Standardizer must be fitted before transform().")
        return (np.asarray(values, dtype=np.float32) - self.mean_) / self.scale_

    def inverse_transform(self, values: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None:
            raise RuntimeError("Standardizer must be fitted before inverse_transform().")
        return np.asarray(values, dtype=np.float32) * self.scale_ + self.mean_


def load_feature_table(path: str | Path, feature_cols: Sequence[str], target_cols: Sequence[str]) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    frame = pd.read_csv(path)
    missing = [name for name in [*feature_cols, *target_cols] if name not in frame.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    x = frame.loc[:, feature_cols].to_numpy(dtype=np.float32)
    y = frame.loc[:, target_cols].to_numpy(dtype=np.float32)
    return x, y, frame


def split_by_year(
    frame: pd.DataFrame,
    train_years: Iterable[int],
    test_years: Iterable[int],
    year_col: str = "year",
) -> tuple[np.ndarray, np.ndarray]:
    if year_col not in frame.columns:
        raise ValueError(f"Column {year_col!r} is required for year-based splitting.")
    train_mask = frame[year_col].isin(list(train_years)).to_numpy()
    test_mask = frame[year_col].isin(list(test_years)).to_numpy()
    return np.flatnonzero(train_mask), np.flatnonzero(test_mask)


def make_train_val_split(
    indices: np.ndarray,
    validation_fraction: float = 0.2,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    train_idx, val_idx = train_test_split(indices, test_size=validation_fraction, random_state=random_state)
    return np.asarray(train_idx), np.asarray(val_idx)


def make_loader(
    x: np.ndarray,
    y: np.ndarray,
    sample_weight: np.ndarray | None = None,
    batch_size: int = 16,
    shuffle: bool = True,
) -> DataLoader:
    if sample_weight is None:
        sample_weight = np.ones(len(x), dtype=np.float32)
    dataset = TensorDataset(
        torch.as_tensor(x, dtype=torch.float32),
        torch.as_tensor(y, dtype=torch.float32),
        torch.as_tensor(sample_weight, dtype=torch.float32),
    )
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)
